<?php
	$rand = rand(1, 99);
	echo "Mensaje de prueba : ( " . $rand . " )";
?>