<?php
include "crearCookie.php";

$frase = isset($_POST["nacimiento"]) ? htmlspecialchars($_POST["nacimiento"]) : "";

if ($_SERVER["REQUEST_METHOD"] === "POST" && strlen($frase) > 0) {
    crearCookie("recordatorio", $frase);
    echo "Recordatorio creado correctamente.<br>";
    echo "<a href='../view/successful.php'>Continuar</a>";
} else {
    header("Location: ../view/recordatorio.php");
}
