<?php
include "borrarCookie.php";
borrarCookie("recordatorio");
header("Location: ../index.php");
