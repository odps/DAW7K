<?php
echo '<p>La contraseña es: ' . $_COOKIE["recordatorio"] . '</p>';
echo '<a href = "../index.php"> Volver </a> ';
