<?php
include "./header.php";
?>
<form action="../controller/recordatorio-ctl.php" method="post">
    <h1>Crear recordatorio</h1>
    <h2>Es obligatorio crear un recordatorio de contraseña</h2>
    <label for="nacimiento">¿En que año naciste?</label><br>
    <input type="number" name="nacimiento" placeholder="Año de nacimiento"><br><br>
    <button type="submit">Crear Recordatorio</button>

</form>
<?php
include "./footer.php";
?>