<?php
include "crearCookie.php";
include "borrarCookie.php";
$guardados = unserialize($_COOKIE["guardados"]);
array_pop($guardados);
if (count($guardados) > 0) {
    crearCookie("guardados", serialize($guardados));
} else {
    borrarCookie("guardados");
}

header("Location: ../index.php");
