<?php
$guardados = unserialize($_COOKIE["guardados"]);
$pass = htmlspecialchars($_REQUEST["pass"]);

if ($_SERVER["REQUEST_METHOD"] === "POST" && strlen($pass) > 0) {


    //validarUserPassword($_COOKIE["usuario"], $pass)
    if ($guardados[$_COOKIE["usuario"]] == $pass) {
        header("Location: ../view/showPass.php");
    } else {
        header("Location: ../view/loginIncorrecto.php");
    }
}
