<?php
include "header.php";
?>

<form action="../controller/olvidado-ctl.php" method="post">
    <h1>Recordatorio de contraseña</h1>
    <label for="pass">¿En que año naciste?</label><br>
    <input type="number" name="pass" placeholder="Año de nacimiento"><br><br>
    <button type="submit">Recordar la clave</button>
</form>

<?php
include "footer.php";
