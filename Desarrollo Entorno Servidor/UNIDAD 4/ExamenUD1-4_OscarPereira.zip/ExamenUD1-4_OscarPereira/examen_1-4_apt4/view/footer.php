<!--footer -->
<div id="footer">
    <hr/>
    <div align="center">- Pie de página -</div>
</div>
<!-- end: wrapper -->
</body>
</html>
