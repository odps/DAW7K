<?php
// Incluimos el header
include 'header.php';
?>
<?php

if (!empty($_COOKIE["guardados"])) {
    if (array_key_exists($_COOKIE["usuario"], unserialize($_COOKIE["guardados"]))) {
        echo "<h1>Bienvenido usuario</h1>";
        echo "<p><b>Login Correcto</b></p>";
        echo "<a href='../index.php'>Volver</a><br>";
        echo "<a href='../controller/elimina_recordatorio.php'>Borrar recordatorio y volver</a>";
    } else {
        header("Location: ./recordatorio.php");
    }
} else {
    header("Location: ./recordatorio.php");
}
?>


<?php
// Incluimos el footer
include 'footer.php';
?>
