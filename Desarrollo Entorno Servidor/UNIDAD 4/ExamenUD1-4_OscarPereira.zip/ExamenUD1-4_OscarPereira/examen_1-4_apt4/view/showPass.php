<?php
$guardados = unserialize($_COOKIE["guardados"]);

echo '<p>La contraseña es: ' . $guardados[$_COOKIE["usuario"]] . '</p>';
echo '<a href = "../index.php"> Volver </a> ';
