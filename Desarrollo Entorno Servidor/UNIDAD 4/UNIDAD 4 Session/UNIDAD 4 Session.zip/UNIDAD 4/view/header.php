<?php

function fnCabecera()
{
?>
    <!DOCTYPE html>
    <html lang="es">

    <head>
        <title>
            <?php
            echo "DAW 7K - OscarP";
            ?>
        </title>
        <meta charset="utf-8" />
        <style>
            body {
                text-align: center;
            }
        </style>
    </head>

    <body>
    <?php
}
