<?php
// Incluimos el header
include 'header.php';
?>

<h1>Bienvenido usuario</h1>
<p><b>Login Correcto</b></p>
<a href="../index.php">Volver</a>

<?php
// Incluimos el footer
include 'footer.php';
?>
