<?php

// Redirigimos al formulario de login
header("Location: view/form_login.php");
?>
