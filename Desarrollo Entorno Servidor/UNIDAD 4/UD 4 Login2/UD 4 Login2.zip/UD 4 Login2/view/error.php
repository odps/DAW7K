<?php

include "header.php";
include  "footer.php";

fnHeader();
echo "<h1> Error 😢</h1>";
echo "Ha ocurrido un error en la validacion de datos";

fnFooter();
