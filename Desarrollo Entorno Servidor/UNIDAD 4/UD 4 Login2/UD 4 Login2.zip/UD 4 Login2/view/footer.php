<?php

function fnFooter()
{
?>
    <footer>
        <br>
        -------------------------------
        <br>
        Pie de página
    </footer>
    </body>

    </html>
<?php
}
