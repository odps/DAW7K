<?php
function  fnFooter()
{
?>
    </body>

    </html>
<?php
}
