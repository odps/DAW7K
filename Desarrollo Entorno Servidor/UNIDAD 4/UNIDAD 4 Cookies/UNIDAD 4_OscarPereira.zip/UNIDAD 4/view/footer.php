<?php

function fnFooter()
{
    echo "<footer>-----------------------------<br>Pie de pagina</footer>";
    echo "</body>

 </html>";
}
