<?php
// Incluimos el header
include 'header.php';
?>

<h1>Login Incorrecto</h1>
<a href="../index.php">Volver</a>

<?php
// Incluimos el footer
include 'footer.php';
?>
