<?php
// Incluimos el header
include 'header.php';
?>

<h2>No has introducido toda la información necesaria</h2>
<a href="../index.php">Volver</a>

<?php
// Incluimos el footer
include 'footer.php';
?>