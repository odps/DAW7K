<?php
// Incluimos el header
include 'header.php';
?>

<h3>Login con Cookies</h3>

<form action="../controller/login_ctl.php" method="post">
    Usuario: <input type="text" name="user" placeholder="nombre de usuario" /><br />
    Password <input type="password" name="password" placeholder="contraseña" /><br />
    Recordar Usuario: <input type="checkbox" name="rec_user"><br />
    <input type="submit" value="Enviar" />
</form>

<?php
// Incluimos el footer
include 'footer.php';
?>
