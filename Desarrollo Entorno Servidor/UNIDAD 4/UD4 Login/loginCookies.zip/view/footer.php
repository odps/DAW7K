<!--footer -->
<div id="footer">
    <hr/>
    <div align="center">- pie de página -</div>
</div>
<!-- end: wrapper -->
</body>
</html>
