<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Cliente;

class ClienteController extends Controller
{
    function list()
    {
        $clientes = Cliente::all();
        return view('cliente.list', ['clientes' => $clientes]);
    }

    function new(Request $request)
    {
        if ($request->isMethod('post')) {

            $validated = $request->validate([
                'dni' => 'required|string|size:9|unique:clientes,dni',
                'nombre' => 'required|string',
                'apellidos' => 'required|string',
                'fecha_nacimiento' => 'required|date|before_or_equal:today',
            ]);

            // recogemos los campos del formulario en un objeto cliente
            $cliente = new Cliente;
            $cliente->dni = $request->dni;
            $cliente->nombre = $request->nombre;
            $cliente->apellidos = $request->apellidos;
            $cliente->fechaN = $request->fechaN;
            $cliente->save();
            return redirect()->route('cliente_list')->with('status', 'Nuevo cliente
' . $cliente->nombreApellidos() . ' creado!');
        }
        // si no venimos de hacer submit al formulario, tenemos que mostrar el formulario
        $clientes = Cliente::all();
        return view('cliente.new', ['clientes' => $clientes]);
    }

    function edit(Request $request, $id)
    {
        if ($request->isMethod('post')) {

            $cliente = Cliente::find($id);

            $validated = $request->validate([
                'dni' => 'required|string|size:9|unique:clientes,dni',
                'nombre' => 'required|string',
                'apellidos' => 'required|string',
                'fecha_nacimiento' => 'required|date|before_or_equal:today',
            ]);

            if ($cliente && $validated) {
                // recogemos los campos del formulario en un objeto cliente
                $cliente->dni = $request->dni;
                $cliente->nombre = $request->nombre;
                $cliente->apellidos = $request->apellidos;
                $cliente->fechaN = $request->fechaN;
                $cliente->save();
                return redirect()->route('cliente_list')->with('status', 'Cliente: ' . $cliente->nombreApellidos() . ' editado correctamente.');
            } else {
                return redirect()->route('cliente_list')->with('error', 'Cliente no encontrado.');
            }
        } else {
            // si no venimos de hacer submit al formulario, tenemos que mostrar el formulario
            $cliente = Cliente::find($id);

            if ($cliente) {
                return view('cliente.edit', ['cliente' => $cliente]);
            } else {
                return redirect()->route('cliente_list')->with('error', 'Cliente no encontrado.');
            }
        }
    }

    function delete($id)
    {
        $cliente = Cliente::find($id);
        $cliente->delete();
        return redirect()->route('cliente_list')->with('status', 'Cliente
' . $cliente->nombreApellidos() . ' eliminado!');
    }
}
