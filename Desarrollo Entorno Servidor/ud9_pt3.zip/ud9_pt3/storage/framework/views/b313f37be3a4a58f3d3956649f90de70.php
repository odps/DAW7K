<!-- Navigation -->
<nav>
    <a href="<?php echo e(route('home')); ?>">Inicio</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('cuenta_list')); ?>">Cuentas</a>
    &nbsp;&nbsp;&nbsp;
    <a href="<?php echo e(route('cliente_list')); ?>">Clientes</a>
</nav><?php /**PATH /opt/lampp/htdocs/practicas/ud9_pt1/resources/views/navbar.blade.php ENDPATH**/ ?>