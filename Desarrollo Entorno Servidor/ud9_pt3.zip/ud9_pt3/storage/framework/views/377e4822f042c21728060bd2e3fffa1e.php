<?php $__env->startSection('title', 'Listado de clientes'); ?>
<?php $__env->startSection('stylesheets'); ?>
<?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>Listado de clientes</h1>
<a href="<?php echo e(route('cliente_new')); ?>">+ Nuevo Cliente</a>
<?php if(session('status')): ?>
<div>
    <strong>Success!</strong> <?php echo e(session('status')); ?>

</div>
<?php endif; ?>
<table style="margin-top: 20px;margin-bottom: 10px;">
    <thead>
        <tr>
            <th>DNI</th>
            <th>Nombre</th>
            <th>Fecha Nacimiento</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($cliente->dni); ?></td>
            <td><?php echo e($cliente->nombreApellidos()); ?></td>
            <td> <?php echo e($cliente->getFechaN()); ?></td>
            <td>
                <a href="<?php echo e(route('cliente_delete', ['id' =>
$cliente->id])); ?>">Eliminar</a>

                <a href="<?php echo e(route('cliente_edit', ['id' =>
$cliente->id])); ?>">Editar</a>

            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/practicas/ud9_pt1/resources/views/cliente/list.blade.php ENDPATH**/ ?>