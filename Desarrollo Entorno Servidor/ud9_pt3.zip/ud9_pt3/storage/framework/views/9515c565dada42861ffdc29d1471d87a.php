<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('stylesheets'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('stylesheets'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div>
        <img src="<?php echo e(asset ('img/logo.png')); ?>" alt="">
        <h2>UD9 Pt1</h2>
        <hr>
        <h3>Práctica para iniciarse en los conceptos básicos de Laravel</h3>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/practicas/ud9_pt1/resources/views/default/home.blade.php ENDPATH**/ ?>