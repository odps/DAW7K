<?php

$datos_distritos = array(
    'Algirós' => 36390,
    'Benicalap' => 47752,
    'Benimaclet' => 28064,
    'Camins al Grau'
    =>  65552,
    'Campanar'  =>  39164,
    'Ciutat  Vella'  =>  27983,
    'L\'Eixample'  =>  42672,
    'Extramurs'  =>  48536,
    'Jesus' => 51941,
    'L\'Olivereta' => 48686,
    'Patraix' => 57798,
    'El Pla del Real' => 30444,
    'Poblats Marítims'
    =>  55486,
    'Pobles  del  Nord'  =>  6744,
    'Pobles  de  l\'Oest'  =>  14546,
    'Pobles  del  Sud'  =>  21289,
    'Quatre 
Carreres' => 74555,
    'Rascanya' => 53566,
    'La Saïdia' => 47013
);
