<?php

for ($star="*"; strlen($star) <= 5; $star = $star . "*") { 
    echo $star . "<br>";
}