# Primera parte del examen de DAW

---

## Formatear correctamente los títulos vale 0.2 ptos

## Formato (0.4 ptos)

Podemos poner un texto en **negrita**, otro en _cursiva_ y un tercero en **_negrita y cursiva_**

También podemos hacerlo en una lista de puntos:

- **negrita**
- _cursiva_
- **_negrita y cursiva_**

## Listas (0.4 ptos)

Además de las listas con puntos tenemos las listas numeradas

1. Uno
2. Dos
3. Tres

### Listas multinivel (es un título de tercer nivel)

También podemos hacer listas multinivel

1. Primer paso

   1. Item 1.1
   2. Item 1.2
      - Incluso combinando con
        - una lista de puntos multinivel
          - dentro del punto 1.2

2. Segundo paso
   1. Item 2.1
   2. Item 2.2

## Segunda parte del examen de DAW

---

### Enlaces e imágenes (0.2 ptos)

---

Podemos poner un enlace a [IES Abastos](www.iesabastos.org)

#### Imágenes

O podemos insertar una imagen

![Pulgar Arriba Emoji](pulgar_arriba.jpg)

### Código (0.2 ptos)

---

Podemos resaltar líneas de código, como: `var saludo='Hola Mundo'`

Y también podemos resaltar bloques de código

```
var linea = readline();
linea = linea.split(' ');
console.log(linea.reverse().join(' '));
```

**Y si ponemos el lenguaje (_javascript_) a continuación de la primera marca de bloque de código, se resalta en el formato de ese lenguaje!!**

```javascript
var linea = readline();
linea = linea.split(" ");
console.log(linea.reverse().join(" "));
```
